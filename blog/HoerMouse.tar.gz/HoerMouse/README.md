### Typecho博客炫彩鼠标插件`HoerMouse`
- fireworks+anime喷墨效果

![fireworks+anime](fireworks+anime.gif)


- 文字气泡效果

![文字气泡效果](bubbleText.gif)
- 爱心气泡效果

![爱心气泡效果](bubbleHeart.gif)
#### 使用方法

- 下载本插件，解压放到`usr/plugins/`目录中
- 文件夹名改为`HoerMouse`
- 登录管理后台，激活插件

#### 联系作者
- Email:`i@hoehub.com`
- 欢迎访问 www.hoehub.com 一起学习讨论

### 许可证 License

- 本项目遵循GPL-3.0开源协议发布。
- 版权所有Copyright © 2018 by Hoe (http://www.hoehub.com)
- All rights reserved。